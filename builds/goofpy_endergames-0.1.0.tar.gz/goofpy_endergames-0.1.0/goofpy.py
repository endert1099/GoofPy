import gc
import math

import pygame

# Goof objects
class goof:
    def __init__(self, goofID: int, goofMeta: str):
        self.goofID = goofID
        self.goofMeta = goofMeta

    def getId(self):
        return self.goofID

    def getMeta(self):
        return self.goofMeta

    def setMeta(self, value):
        try:
            self.goofMeta = value
        except:
            return False
        return True
    getId.__doc__ = "Returns the ID of the object"
    getMeta.__doc__ = "Gets the meta value of the object"
    setMeta.__doc__ = "Sets the meta value of the object"

goof.__doc__ = "Goof objects - Objects on which GoofPy is built on."

# External functions that relate to goof objects
def getObjectByClass(c):
    objs = []
    for obj in gc.get_objects():
        if isinstance(obj, c):
            objs.append(obj)
    return objs


def getMetaByID(gid):
    objs = getObjectByClass(goof)
    for o in objs:
        if o.goofID == gid:
            return o.goofMeta
    return False


def compareMeta(originalID, newID):
    try:
        ometa = getMetaByID(originalID)
        nmeta = getMetaByID(newID)
    except:
        raise ValueError("ID was not valid")
    if ometa == nmeta:
        return True
    else:
        return False


def getObjWithID(gid):
    objs = getObjectByClass(goof)
    for o in objs:
        if o.goofID == gid:
            return o


def getObjsWithMeta(meta):
    objs = getObjectByClass(goof)
    robjs = []
    for o in objs:
        if o.goofMeta == meta:
            robjs.append(o)
    return robjs


# Translate goof objects into other objects
class Creator:

    def givePosition2D(self, obj: goof, x: float, y: float, zIndex: int):
        gobj = GameObject(obj.goofID, x, y, 0.0, "", "2D", zIndex)
        return gobj

    def givePosition3D(self, obj: goof, x: float, y: float, z: float):
        gobj = GameObject(obj.goofID, x, y, z, "", "3D")
        return gobj

    def new2D(self, x: float, y: float, zIndex: int, data):
        all_objs = getObjectByClass(goof)
        m = 0
        for obj in all_objs:
            if obj.goofID > m:
                m = obj.goofID
        m = m + 1

        gobj = GameObject(m, x, y, 0.0, data, "2D", zIndex)
        return gobj

    def new3D(self, x: float, y: float, z: float, data):
        all_objs = getObjectByClass(goof)
        m = 0
        for obj in all_objs:
            if obj.goofID > m:
                m = obj.goofID
        m = m + 1

        gobj = GameObject(m, x, y, z, data, "3D")
        return gobj


# Game objects to be converted by the creator
class GameObject:
    def __init__(self, gid, x, y, z, data, gtype, zIndex=0):
        self.gid = gid
        self.x = x
        self.y = y
        self.z = z
        self.data = data
        self.gtype = gtype
        self.zIndex = zIndex

    def formatData(self):
        nextc = 0
        data = []
        for i in self.data:
            if nextc > 0:
                data.insert(nextc - 1, i)
                nextc = 0

            if i == "scalex":
                nextc = 1
            elif i == "scaley":
                nextc = 2
            elif i == "scalez":
                nextc = 3
            elif i == "collider":
                nextc = 4
            elif i == "isActive":
                nextc = 5
            elif i == "isInvis":
                nextc = 6
        return data

    def getScale(self):
        data = self.formatData()
        return data[0:3]

    def getCollider(self):
        data = self.formatData()
        return data[3]

    def getActive(self):
        data = self.formatData()
        return data[4]

    def getInvis(self):
        data = self.formatData()
        return data[5]


# External functions that relate to GameObjects
def readFormattedData(data: list, valueID):
    return data[valueID - 1]

# Still working this one out
# TODO: FIX THIS(0.2.0/0.3.0)
'''def orderByZIndex():
    objs = getObjectByClass(GameObject)
    return objs.sort(objs, gid)'''

# Player class
class Player:
    def __init__(self, x, y, z, facing, fov):
        self.x = x
        self.y = y
        self.z = z
        self.facing = facing
        self.fov = fov

    def isColliding(self, obj: GameObject):
        objData = obj.formatData()
        objScale = obj.getScale()
        isColliding: bool = False
        if obj.getCollider() and obj.getActive():
            for i in range(3):
                objScale[i] = objScale[i] / 2
            if obj.x - objScale[0] <= self.x <= obj.x + objScale[0]:
                if obj.y - objScale[1] <= self.y <= obj.y + objScale[1]:
                    if obj.z - objScale[2] <= self.z <= obj.z + objScale[2]:
                        isColliding = True
        return isColliding

    def canSee(self, obj: GameObject):
        if not obj.getInvis() and obj.getActive():
            if self.isColliding(obj):
                return True  # If they're in the block, they can probably see it

            x = obj.x - self.x
            y = obj.x - self.x

            t = math.atan2(y, x) # BEST FUNCTION IN PYTHON

            t = t * (180 / math.pi)
            if t < 0:
                t = 360 + t

            halfFOV = self.fov / 2

            if self.facing - halfFOV <= t <= self.facing + halfFOV and self.z - halfFOV <= obj.z <= self.z + halfFOV:
                return True
            return False

    def move(self, d: float):
        o = self.facing * (math.pi / 180)
        x = d * math.cos(o)
        y = d * math.sin(o)
        self.x = self.x + round(x, 2)
        self.y = self.y + round(y, 2)
    def turn(self, deg: float):
        if deg > 360:
            raise ValueError("Turning degrees cannot be over 360!")
        f = self.facing + deg
        if f > 360:
            f = f - 360
        if f < 0:
            f = f + 360
        self.facing = f

class Game:
    def __init__(self, height: int = 1, width: int = 0, engine=pygame): # supports only PyGame for now
        self.width = width
        self.height = height
        self.engine = engine

        if self.engine == pygame:
            self.c = self.engine.time.Clock()
            self.d = self.engine.display
            self.s = self.d.set_mode((self.width, self.height))
        self.init = False
    def initEngine(self):
        if self.engine == pygame:
            self.engine.init()
            self.init = True
    def keyPressed(self, key: str):
        if self.engine == pygame and self.init:
            k = self.engine.key.get_pressed()
            k = k[self.engine.key.key_code(key)]
            return k
    def runAtFPS(self, fps: int):
        if self.engine == pygame and self.init:
            self.s.fill("black")
            self.d.flip()
            self.c.tick(fps)
    def getEvents(self):
        if self.engine == pygame and self.init:
            e = []
            for event in pygame.event.get():
                e.append(event)
            return e
    def run(self, gameFunction, fps: int):
        if self.engine == pygame and self.init:
            running = True
            while running:
                e = self.getEvents()
                if not e is None:
                    if self.engine.QUIT in e:
                        running = False

                gameFunction()

                self.runAtFPS(fps)
